package com.KG.service.member;

import org.springframework.ui.Model;

public interface MemberService {

	public boolean execute_Boo(Model model);
	public String execute_Str(Model model);
	public int execute_Int(Model model);
}
