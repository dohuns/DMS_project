package com.KG.dto;

public class LikeDTO {
	
	private String l_id;
	private int l_boardNum;
	private String l_divLike;
	
	
	public String getL_id() {
		return l_id;
	}
	public void setL_id(String l_id) {
		this.l_id = l_id;
	}
	public int getL_boardNum() {
		return l_boardNum;
	}
	public void setL_boardNum(int l_boardNum) {
		this.l_boardNum = l_boardNum;
	}
	public String getL_divLike() {
		return l_divLike;
	}
	public void setL_divLike(String l_divLike) {
		this.l_divLike = l_divLike;
	}
	
	

}
